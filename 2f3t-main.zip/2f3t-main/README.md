# DUPLA
## Nome1 - 24 --- Nome2 - 6
